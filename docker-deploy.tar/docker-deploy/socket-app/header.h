#ifndef _HEADER_H__
#define _HEADER_H__

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <vector>

#include <cstring>
#include <cstdio>
#include <iostream>

#include <sys/types.h>
#include <sys/socket.h>

#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <fcntl.h>

#include <ctype.h>
#include <cstring>
#include <signal.h>

#include <unistd.h>

#include <errno.h>

#include <pthread.h>
#include <fstream>
#include <sys/stat.h>
#include <sys/wait.h>
#include <time.h>

#include <stdbool.h>

#endif
