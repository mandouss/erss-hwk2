A web cache (or HTTP cache) is an information technology for the temporary storage (caching) of web documents, such as HTML pages and images, to reduce server lag. 
 
 
 the project includes the following files:
 
 cache.cpp  cache.h  header.h  log*  log.cpp  log.h  Makefile  parser.cpp  parser.h  README.md  socket.cpp  socket.h  test.c  threadcontrol.cpp  threadcontrol.h  time.h